module.exports = {
  host: 'smtp.ethereal.email',
  port: 587,
  auth: {
    user: 'eda.dicki@ethereal.email',
    pass: 'yCxU6gD7RpZukh89rf',
  },
}
